<?php
include "database.php";
if (isset($_POST['submit'])){
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$query=mysqli_query($connection,"INSERT INTO form(name,email,password) VALUES('$name','$email','$password')");
if($query){
    header("location:trial.php");
    echo "Data Inserted";
}
else{
    echo "error";
}
} 
?>