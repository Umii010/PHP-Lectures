<?php 
$host="localhost";
$user="root";
$password="";
$dbName="html";
$connection= new mysqli($host,$user,$password,$dbName);
if($connection->connect_error){
echo "Connection failed";

}
else{
    echo "Connected Successfully";
}
?>