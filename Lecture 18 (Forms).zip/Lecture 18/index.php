<!doctype html>
<html>
<head>
</head>
<body>
</body>
</html>
<html>
<title>
Sign Up From
</title>
<center>
<head>
<style>
body{
background-color: lightgoldenrodyellow;
}

</style>
<p>
<img src="capture.jpeg" width ="160" height="150">
</p>

<h1>Habib Oil </h1>
</head>
<body>
<table>
<form action="insert.php" method="post">
<tr>
<td>Name</td>
<td><input type="text" name="name"></td>
</tr>
<tr>
<td>City</td>
<td><input type="text"name="city"></td>
</tr>
<tr>
<td>Country</td>
<td><input type="text" name="country"></td>
</tr>
<tr>
<td>Email</td>
<td><input type="text" name="email"></td>
</tr>
<tr>
<td>PhoneNumber</td>
<td><input type="text" name="phonenumber"></td>
<tr>
<td>Address</td>
<td><input type="text" name="address"></td>
</tr>


<tr>
<td>Feedback</td>
<td><textarea id="feedback" name="feedback" rows="3" cols="20">

</textarea>	
</tr>
<tr>


<td><button type="submit" value="Submit" name="save" id="save">Submit</button></td>

<td><input type="Reset" value="Reset"></td>

</tr>
</form>
</center>
</table>
</body>
</html>