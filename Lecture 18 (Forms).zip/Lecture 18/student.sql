-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2023 at 06:12 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iqra`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(20) NOT NULL,
  `name` varchar(17) NOT NULL,
  `city` varchar(17) NOT NULL,
  `country` varchar(17) NOT NULL,
  `email` varchar(17) NOT NULL,
  `phonenumber` varchar(17) NOT NULL,
  `address` varchar(17) NOT NULL,
  `feedback` varchar(17) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `city`, `country`, `email`, `phonenumber`, `address`, `feedback`) VALUES
(1, 'Muhammad Umer Sha', 'Rawalpindi', 'Pakistan', 'umii020@hotmail.c', '03010157807', 'House no ZA 14/1 ', ' \r\n  Nice product'),
(2, 'Ahmer Nadeem', 'Rawalpindi', 'Pakistan', 'imran@gmail.com', '03111503740', 'Rawalpindi pakist', ' \r\n  Amazing'),
(3, 'Harry', 'Washigton,DC', 'USA', 'harry@21yahoo.com', '+1872323582', 'Street no: 21, ha', ' \r\n  Nice One!!!'),
(4, 'Abdul', 'Rawalpindi', 'Pakistan', 'sajjadali786sj@gm', '03135226348', 'House no ZA 14/1 ', '\r\nStunning');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
