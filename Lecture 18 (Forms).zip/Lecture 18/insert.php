
<?php
include "db.php";
if (isset($_POST['save'])){
$name=$_POST['name'];
$city=$_POST['city'];
$country=$_POST['country'];
$email=$_POST['email'];
$phonenumber=$_POST['phonenumber'];
$address=$_POST['address'];
$feedback=$_POST['feedback'];


$query=mysqli_query($conn,"INSERT INTO student (name,city,country,email,phonenumber,address,feedback) VALUES('$name','$city','$country','$email','$phonenumber','$address','$feedback')");

if ($query)
{
header("location:index.php");
echo "DATA INSERTED";

}
else{
echo "ERROR";
}

}
?>

