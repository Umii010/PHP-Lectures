<?php
$host="localhost";
$user="root";
$password="";
$dbName="iqra";
$conn=mysqli_connect($host,$user,$password,$dbName);
?>

